<?php 
include 'koneksi.php';
$data_edit = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE nim = '".$_GET['nim']."' ");
$result = mysqli_fetch_array($data_edit);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Edit Data</title>
</head>
<body>
	<div style="background-color: #F5F5F5; border: grey 2px solid; margin: 20px 400px 0px 400px; border-radius: 10px; padding: 20px 50px 50px 50px;">
	<h2 style="text-align: center">Edit Data Mahasiswa</h2>

	<br>
	<br>
	<form action="" method="POST">
		<table>
			<tr>
				<td>NIM</td>
				<td>:</td>
				<td><input type="text" name="nim" value="<?php echo $result['nim']  ?>" required></td>
			</tr>
			<tr>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td><input type="text" name="nama" value="<?php echo $result['nama_lengkap']  ?>" required></td>
			</tr>
			<tr>
				<td>Telepon</td>
				<td>:</td>
				<td><input type="text" name="telp" value="<?php echo $result['telepon']  ?>" required></td>
			</tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><input type="email" name="email" value="<?php echo $result['email']  ?>" required></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><input type="submit" name="edit" placeholder="Simpan" required style="font-family: sans-serif;
    font-size: 10px;
    background: #22a4cf;
    color: white;
    border: grey 2px solid;
    border-radius: 5px;
    padding: 11px 40px;
    margin-top: 10px; text-decoration: none;"></td>
			</tr>
		</table>
	</form>
		<div style="margin: 20px 0px 0px 0px; width: 250px; " >
		<a href="index.php" style="font-family: sans-serif;
    font-size: 10px;
    background: #22a4cf;
    color: white;
    border-radius: 5px;
    padding: 10px 15px;
    margin-top: 10px; text-decoration: none;  ">Back</a>
	</div>
	<?php 
	if (isset($_POST['edit'])) {
		$update = mysqli_query($conn, "UPDATE mahasiswa SET nama_lengkap = '".$_POST['nama']."', telepon = '".$_POST['telp']."', email = '".$_POST['email']."' WHERE nim =  '".$_GET['nim']."'");
		if ($update) {
			echo "<script>alert('Update Berhasil!');</script>";
		}else{
			echo "<script>alert('Update Tidak Berhasil!');</script>";
		}
	}
	?>
 	
</body>
</html>