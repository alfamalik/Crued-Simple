<!DOCTYPE html>
<html>
<head>
	<title>Halaman Input Data</title>
</head>

<body >
	<div style="background-color: #F5F5F5; border: grey 2px solid; margin: 20px 400px 0px 400px; border-radius: 10px; padding: 20px 0px 50px 0px;">
	<h2 style="text-align: center">Input Data Mahasiswa</h2>
	
	<br>
	<br>
	<form action="" method="POST" style="margin: 0 auto; width: 250px;">
		<table>
			<tr>
				<td>NIM</td>
				<td>:</td>
				<td><input type="text" name="nim" placeholder="NIM" required></td>
			</tr>
			<tr>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td><input type="text" name="nama" placeholder="Nama Lengkap" required></td>
			</tr>
			<tr>
				<td>Telepon</td>
				<td>:</td>
				<td><input type="text" name="telp" placeholder="Telepon" required></td>
			</tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><input type="email" name="email" placeholder="Email" required></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><input  type="submit" name="simpan" placeholder="Simpan" required style="font-family: sans-serif;
    font-size: 10px;
    background: #22a4cf;
    color: white;
    border: grey 2px solid;
    border-radius: 5px;
    padding: 11px 40px;
    margin-top: 10px; text-decoration: none;"></td>
			</tr>
		</table>
	</form>
	<br>

	<div style="margin: 0 auto; width: 250px; " >
		<a href="index.php" style="font-family: sans-serif;
    font-size: 10px;
    background: #22a4cf;
    color: white;
    border-radius: 5px;
    padding: 10px 15px;
    margin-top: 10px; text-decoration: none;  ">Back</a>
	</div>
	<?php 
	include 'koneksi.php';
	if (isset($_POST['simpan'])) {
	$insert = mysqli_query($conn, "INSERT INTO mahasiswa VALUES 
	   ('".$_POST['nim']."',
		'".$_POST['nama']."',
		'".$_POST['telp']."',
		'".$_POST['email']."') ");
	if ($insert) {
		echo "<script>alert('Data Berhasil Ditambahkan!');</script>";
	}else{
		echo "<script>alert('Data Gagal Ditambahkan!');</script>";
	}
	}
	 ?>
	 </div>
</body>
</html>