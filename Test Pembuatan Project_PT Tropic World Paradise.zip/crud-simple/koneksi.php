<?php
$conn =	mysqli_connect('localhost', 'root', '', 'database_crud' );
if(!$conn){
		echo 'gagal terhubung';
	}
?>