<!DOCTYPE html>
<html>
<head>
	<title>Halaman Data Mahasiswa</title>
</head>
<body>
<h2 style="text-align: center">Data Mahasiswa</h2>
<br>

<div style=" margin: 20px 200px 0px 200px; ">
<a href="input.php" style="font-family: sans-serif;
    font-size: 13px;
    background: #22a4cf;
    color: white;
    border-radius: 5px;
    padding: 10px 15px;
    margin-top: 10px; text-decoration: none;">Tambah Data</a>
<br>
<br>
<table border="1" cellspacing="0" width="100%" style="border: #808080 20px ;">
	<tr style="text-align: center; color: #22a4cf ; background-color: #ccccff;  ">
		<td>No</td>
		<td>NIM</td>
		<td>Nama Mahasiswa</td>
		<td>Telepon</td>
		<td>Email</td>
		<td>Opsi</td>
	</tr>

	<?php
	include 'koneksi.php';
	$no =1;
	$select = mysqli_query($conn, "SELECT * FROM mahasiswa");
	if (mysqli_num_rows($select) > 0) {

	while($hasil = mysqli_fetch_array($select)){
	?>
	<tr>
		<td><?php echo $no++ ?> </td>
		<td><?php echo $hasil['nim'] ?></td>
		<td><?php echo $hasil['nama_lengkap'] ?></td>
		<td><?php echo $hasil['telepon'] ?></td>
		<td><?php echo $hasil['email'] ?></td>
		<td>
			<a href="edit.php?nim=<?php echo $hasil['nim']?>">edit</a> || 
			<a href="delete.php?nim=<?php echo $hasil['nim']?> " onclick="return confirm('Are you sure?')">hapus</a>

		</td>
	</tr>
	<?php }}else { ?>
	<tr>
		<td colspan="6" align="center">Data Kosong</td>
	</tr>
	<?php  } ?>
</table>
</div>
</body>
</html>